package cn.shiyun.entity;

/**
 * Created by 陶鹏飞 on 2017/7/20.
 */
public class Entity {
}
