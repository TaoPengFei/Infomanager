GRANT ALL PRIVILEGES ON hibernate.* to 'guest'@'%' IDENTIFIED BY '111111' WITH GRANT OPTION;
flush privileges;
GRANT ALL PRIVILEGES ON bi.* to 'guest'@'%' IDENTIFIED BY '111111' WITH GRANT OPTION;
flush privileges;