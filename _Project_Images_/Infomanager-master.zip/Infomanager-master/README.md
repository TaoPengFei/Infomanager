## redis_jedis 的运行原理
![Image](https://github.com/TaoPengFei/Infomanager/blob/master/_Project_Images_/redis_jedis.png)

